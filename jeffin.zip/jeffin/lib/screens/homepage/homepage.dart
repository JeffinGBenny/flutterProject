import 'package:flutter/material.dart';
import 'package:jeffin/models/productDataModels.dart';
import 'package:jeffin/screens/form/formpage.dart';
import 'package:jeffin/screens/homepage/widgets/Product.dart';
import 'package:jeffin/screens/showall/showalldetails.dart';
//import 'package:jeffin/theme/theme.dart';
import 'widgets/customAppbar.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  void onPressedEvent(BuildContext context) {
    Navigator.of(context).pushNamed(ShowAllDeatils.routeName);
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  List<ProductDataModel> productData = [
    ProductDataModel(
      productName: 'Refrigerator',
      companyName: 'LG',
      price: 30000,
    ),
    ProductDataModel(
      productName: 'AC',
      
      companyName: 'voltas',
      price: 48000,
    ),
    ProductDataModel(
      productName: 'TV',
     
      companyName: 'Samsung',
      price: 22300,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Floationactionbtncustom(),
      drawer: Drawer(
        child: ListView(
          children: [
            ListTile(
              title: Text('form'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushNamed(FormPage.routeName);
              },
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomAppBar(
                ontap: () {
                  _scaffoldKey.currentState.openDrawer();
                },
              ),
              
              titlbar(),
              priceTagList(context),
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: productData.length,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                    onTap: () {
                      Map argumnets = {
                        'productname': productData[index].productName,
                        'price': productData[index].price
                      };

                      Navigator.of(context).pushNamed(ShowAllDeatils.routeName,
                          arguments: argumnets);
                    },
                    child: Product(
                      imgpath: 'assets/img/ac.jpg',
                     
                      price: productData[0].price.toString(),
                      
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Container priceTagList(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width - 40,
      height: 60,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          GreyCard(price: "₹8888"),
          GreyCard(price: "₹8888"),
          GreyCard(price: "₹8888"),
          GreyCard(price: "₹8888"),
          GreyCard(price: "₹8888"),
          GreyCard(price: "₹8888"),
          GreyCard(price: "₹8888"),
        ],
      ),
    );
  }

  Row titlbar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
     
      children: [  Icon(Icons.more_vert)
      ], 
    );
  }
}

class Floationactionbtncustom extends StatelessWidget {
  const Floationactionbtncustom({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Color.fromRGBO(10, 60, 63, 1)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.place,
            color: Colors.white,
          ),
          Text(
            "Map View",
            style: TextStyle(color: Colors.white),
          )
        ],
      ),
    );
  }
}

class GreyCard extends StatelessWidget {
  const GreyCard({
    Key key,
    this.price,
  }) : super(key: key);

  final String price;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10, bottom: 10, right: 10),
      decoration: BoxDecoration(
          color: Colors.black12, borderRadius: BorderRadius.circular(30)),
      padding: EdgeInsets.all(12),
      child: Text(
        "$price",
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
      ),
    );
  }
}
