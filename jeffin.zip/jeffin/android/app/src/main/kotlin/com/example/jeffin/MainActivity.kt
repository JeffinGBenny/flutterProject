package com.example.jeffin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
