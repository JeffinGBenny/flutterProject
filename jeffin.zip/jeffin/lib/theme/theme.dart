import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

TextStyle greySmall = new TextStyle(
  fontFamily: 'Open Sans',
  fontWeight: FontWeight.bold,
  color: Colors.black26,
);
TextStyle blackMedium = new TextStyle(
  fontWeight: FontWeight.bold,
  fontSize: 20,
);
