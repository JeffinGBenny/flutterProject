class ProductDataModel {
  String productName;
  double price;
  String companyName;
  ProductDataModel({
    this.productName,
    this.companyName,
    this.price,
  });
}
